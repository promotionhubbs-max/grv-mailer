GRV MAILER - CLOUDFLARE WORKER

Files:
- index.js        Worker application
- wrangler.jsonc  Cloudflare Worker configuration

For iPhone setup without copy/paste:
1. Upload these files to a GitHub repository.
2. In Cloudflare Dashboard > Workers & Pages > Create application > Import repository.
3. Select the GitHub repository and deploy.

This prototype serves the Grv Mailer UI. Real Gmail/Outlook OAuth and sending backend still need to be connected before production email sending.
